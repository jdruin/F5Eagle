"xekri" is a Lojban word that means "extermely dark-colored".
This skin was contributed by Andrew Moore.
